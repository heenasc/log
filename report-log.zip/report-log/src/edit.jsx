/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, TextField, DatePicker, Select, Option,Button,render,Text,User,DashboardGadget,useProductContext } from "@forge/ui";
import api, { route } from "@forge/api";

const Edit = () => {
  // let [someCount,setSomeCount] = useState(0)

   const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [project, setProject] = useState("");
  const [projects, setProjects] = useState([]);
  const [roles, setRoles] = useState([]); 
  const [selectedRoleUserAccountIds, setSelectedRoleUserAccountIds] = useState([]);
  const [accountIds, setaccountIds] = useState([]);
    useState(fetchProjects());
    useState(fetchRoles());
  let [userCount, setUserCount] = useState(1);
  const onSubmit = values => {
        console.log("values in edit",values);
    return values;

  };

  const handleAddButtonClick = () => {
    let value = userCount;
    setUserCount(value+1);
    // console.log(userCount)
    // setSomeCount(count => count +1);
  };

  const renderUserFields = () => {
    const userFields = [];
    let users = {}
    for (let i = 0; i < userCount; i++) {
      // users[<UserPicker lable="user" name={`user${i}`} text="Picker User" />] =   <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />
      userFields.push(
        
        <UserPicker lable="user" name={`user${i}`} text="Picker User" /> 
         
        // <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />

      );
    }


    return userFields;
  };

  async function fetchProjects() {
    try {
      console.log("entered fetchProjects")
      const response = await api.asUser().requestJira(route`/rest/api/3/project/search`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchProjects")
      const responseJson = await response.json();
      //const issueArray = responseJson.issues.map(obj => obj.key);
      setProjects(responseJson.values);
      //console.log("Projects:", responseJson.values);
      console.log("exit fetchProjects")
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
    }
  
  async function fetchRoles() {
  // Inside fetchRoles function
//export const roleUsersJson = await roleUsersResponse.json();
//export const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
    try {
      // Fetch roles API call
            console.log("entered fetchroles")
      const response = await api.asUser().requestJira(route`/rest/api/3/role`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchrole")
      const responseJson = await response.json();
      setRoles(responseJson);
      console.log("exit fetchrole")
      if (responseJson.length > 0) {
      const roleId = responseJson[0].id; // Get the ID of the default selected role
      const roleUsersResponse = await api.asUser().requestJira(route`/rest/api/3/role/${roleId}`);
      const roleUsersJson = await roleUsersResponse.json();
      const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
      setSelectedRoleUserAccountIds(accountIds);
      //setaccountIds(accountIds);
      console.log("accountIds",accountIds);
    }
    } catch (error) {
      console.error("Error fetching roles:", error);
    }
  }

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <Select
          label="Select Project"
          name="project" // Add the name prop
          value={project}
          onChange={(newValue) => setProject(newValue)}
        >
          <Option label="Select a project" value="" />
        {projects.map((proj) => (
          <Option key={proj.id} label={proj.name} value={proj.key} />
        ))}
      </Select>
      <Select
        label="Select Role"
        name="roles"
        isMulti={true} // Allow selecting multiple roles
        value={roles}
        onChange={(newRoles) => setRoles(newRoles)}
      >
        {roles.map((role) => (
          <Option key={role.id} label={role.name} value={role.id} />
        ))}
      </Select>
      <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
    </DashboardGadgetEdit>
  );
};


export default Edit;*/
//below code working fine
/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, TextField, DatePicker, Select, Option,Button,render,Text,User,DashboardGadget,useProductContext } from "@forge/ui";
import api, { route } from "@forge/api";

const Edit = () => {
  // let [someCount,setSomeCount] = useState(0)

   const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [project, setProject] = useState("");
  const [projects, setProjects] = useState([]);
  const [roles, setRoles] = useState([]); 
  const [selectedRoleUserAccountIds, setSelectedRoleUserAccountIds] = useState([]);
  const [accountIds, setaccountIds] = useState([]);
    useState(fetchProjects());
    useState(fetchRoles());
  let [userCount, setUserCount] = useState(1);
  const onSubmit = values => {
        console.log("values in edit",values);
    return values;

  };

  const handleAddButtonClick = () => {
    let value = userCount;
    setUserCount(value+1);
    // console.log(userCount)
    // setSomeCount(count => count +1);
  };

  const renderUserFields = () => {
    const userFields = [];
    let users = {}
    for (let i = 0; i < userCount; i++) {
      // users[<UserPicker lable="user" name={`user${i}`} text="Picker User" />] =   <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />
      userFields.push(
        
        <UserPicker lable="user" name={`user${i}`} text="Picker User" /> 
         
        // <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />

      );
    }


    return userFields;
  };

  async function fetchProjects() {
    try {
      console.log("entered fetchProjects")
      const response = await api.asUser().requestJira(route`/rest/api/3/project/search`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchProjects")
      const responseJson = await response.json();
      //const issueArray = responseJson.issues.map(obj => obj.key);
      setProjects(responseJson.values);
      //console.log("Projects:", responseJson.values);
      console.log("exit fetchProjects")
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
    }
  
  async function fetchRoles() {
  // Inside fetchRoles function
//export const roleUsersJson = await roleUsersResponse.json();
//export const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
    try {
      // Fetch roles API call
            console.log("entered fetchroles")
      const response = await api.asUser().requestJira(route`/rest/api/3/role`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchrole")
      const responseJson = await response.json();
      setRoles(responseJson);
      console.log("exit fetchrole")
      if (responseJson.length > 0) {
      const roleId = responseJson[0].id; // Get the ID of the default selected role
      const roleUsersResponse = await api.asUser().requestJira(route`/rest/api/3/role/${roleId}`);
      const roleUsersJson = await roleUsersResponse.json();
      const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
      setSelectedRoleUserAccountIds(accountIds);
      //setaccountIds(accountIds);
      console.log("accountIds",accountIds);
    }
    } catch (error) {
      console.error("Error fetching roles:", error);
    }
  }

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <Select
          label="Select Project"
          name="project" // Add the name prop
          value={project}
          onChange={(newValue) => setProject(newValue)}
        >
          <Option label="Select a project" value="" />
        {projects.map((proj) => (
          <Option key={proj.id} label={proj.name} value={proj.key} />
        ))}
      </Select>
      <Select
        label="Select Role"
        name="roles"
        value={roles}
        onChange={(newRoles) => setRoles(newRoles)}
      >
        {roles.map((role) => (
          <Option key={role.id} label={role.name} value={role.id} />
        ))}
      </Select>
      <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
    </DashboardGadgetEdit>
  );
};


export default Edit;*/
//now i want to add all option under roles

  
/*async function fetchRolesAndUsers(projectKey) {
  try {
    // Fetch roles API call
    const rolesResponse = await api.asUser().requestJira(route`/rest/api/3/project/TEST/role`);
    const responseJson = await rolesResponse.json();
    console.log("rolesJson", responseJson);
    setRoles(responseJson);
    // Iterate through the role URLs and fetch users for each role
    const allAccountIds = [];

    for (const roleUrl of Object.values(responseJson)) {
      console.log("roleUrl",roleUrl);
      // Extract the roleId from the roleUrl
      const lastRoleId = roleUrl.split('/').pop();
      console.log("lastRoleId", lastRoleId);

      //if (responseJson.length > 0) {
      //const lastRoleId = lastRoleId[0].id; // Get the ID of the default selected role
     
      const roleUsersResponse = await api.asUser().requestJira(route`/rest/api/3/role/${lastRoleId}`);
      console.log("lastRoleId1",lastRoleId);
      const roleUsersJson = await roleUsersResponse.json();
      const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
      setSelectedRoleUserAccountIds(accountIds);
      //setaccountIds(accountIds);
      console.log("accountIds",accountIds);
      //} else {
      //  console.error(`No actors found for role with ID ${lastRoleId}`);
      //}
    }
    
    console.log("lastRoleId", lastRoleId);
    console.log("allAccountIds",accountIds);
    // Set the selected role to "all" and its user account IDs
    setSelectedRole("all");
    setSelectedRoleUserAccountIds(accountIds);
  } catch (error) {
    console.error("Error fetching roles and users:", error);
  }
}*/
/*async function fetchRolesAndUsers(projectKey) {
  try {
    // Fetch roles API call
    const rolesResponse = await api.asUser().requestJira(route`/rest/api/3/project/TEST/role`);
    const responseJson = await rolesResponse.json();
    console.log("rolesJson", responseJson);
    setRoles(responseJson);

    // Iterate through the role URLs and fetch users for each role
    const allAccountIds = [];

    for (const roleUrl of Object.values(responseJson)) {
      console.log("roleUrl", roleUrl);
      // Extract the roleId from the roleUrl
      const lastRoleId = roleUrl.split('/').pop();
      console.log("lastRoleId", lastRoleId);

      // Fetch users for the current role
      const roleUsersResponse = await api.asUser().requestJira(route`/rest/api/3/role/${lastRoleId}`);
      console.log("lastRoleId1", lastRoleId);
      const roleUsersJson = await roleUsersResponse.json();

      // Check if roleUsersJson.actors exists and is an array
      if (Array.isArray(roleUsersJson.actors)) {
        const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
        setSelectedRoleUserAccountIds(accountIds);
        // Add the accountIds to the overall list
        allAccountIds.push(...accountIds);
      } else {
        console.error(`No actors found for role with ID ${lastRoleId}`);
      }
    }

    console.log("allAccountIds", allAccountIds);

    // Set the selected role to "all" and its user account IDs
    setSelectedRole("all");
    setSelectedRoleUserAccountIds(allAccountIds);
  } catch (error) {
    console.error("Error fetching roles and users:", error);
  }
}*/


//this below code working fine for All users but if i am selecting single role it throws error function not calling
/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, TextField, DatePicker, Select, Option,Button,render,Text,User,DashboardGadget,useProductContext } from "@forge/ui";
import api, { route } from "@forge/api";

const Edit = () => {
  // let [someCount,setSomeCount] = useState(0)

   const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [project, setProject] = useState("");
  const [projects, setProjects] = useState([]);
  const [roles, setRoles] = useState([]); 
  const [selectedRoleUserAccountIds, setSelectedRoleUserAccountIds] = useState([]);
  const [accountIds, setaccountIds] = useState([]);
    useState(fetchProjects());
    useState(fetchRoles());
  let [userCount, setUserCount] = useState(1);
  const onSubmit = values => {
        console.log("values in edit",values);
    return values;

  };

  const handleAddButtonClick = () => {
    let value = userCount;
    setUserCount(value+1);
    // console.log(userCount)
    // setSomeCount(count => count +1);
  };

  const renderUserFields = () => {
    const userFields = [];
    let users = {}
    for (let i = 0; i < userCount; i++) {
      // users[<UserPicker lable="user" name={`user${i}`} text="Picker User" />] =   <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />
      userFields.push(
        
        <UserPicker lable="user" name={`user${i}`} text="Picker User" /> 
         
        // <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />

      );
    }


    return userFields;
  };

  async function fetchProjects() {
    try {
      console.log("entered fetchProjects")
      const response = await api.asUser().requestJira(route`/rest/api/3/project/search`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchProjects")
      const responseJson = await response.json();
      //const issueArray = responseJson.issues.map(obj => obj.key);
      setProjects(responseJson.values);
      //console.log("Projects:", responseJson.values);
      console.log("exit fetchProjects")
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
    }
  
  async function fetchRoles() {
  // Inside fetchRoles function
//export const roleUsersJson = await roleUsersResponse.json();
//export const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
    try {
      // Fetch roles API call
            console.log("entered fetchroles")
      const response = await api.asUser().requestJira(route`/rest/api/3/role`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchrole")
      const responseJson = await response.json();
      setRoles(responseJson);
      console.log("exit fetchrole")
    } catch (error) {
      console.error("Error fetching roles:", error);
    }
  }

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <Select
          label="Select Project"
          name="project" // Add the name prop
          value={project}
          onChange={(newValue) => setProject(newValue)}
        >
          <Option label="Select a project" value="" />
        {projects.map((proj) => (
          <Option key={proj.id} label={proj.name} value={proj.key} />
        ))}
      </Select>
      <Select
        label="Select Role"
        name="roles"
        value={roles}
        onChange={(newRoles) => setRoles(newRoles)}
      >
	<Option label='All' value='all' />
        {roles.map((role) => (
          <Option key={role.id} label={role.name} value={role.id} />
        ))}
      </Select>
      <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
    </DashboardGadgetEdit>
  );
};


export default Edit;*/




//this function call for both all and single role also
/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, TextField, DatePicker, Select, Option,Button,render,Text,User,DashboardGadget,useProductContext } from "@forge/ui";
import api, { route } from "@forge/api";

const Edit = () => {
  // let [someCount,setSomeCount] = useState(0)

   const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [project, setProject] = useState("");
  const [projects, setProjects] = useState([]);
  const [roles, setRoles] = useState([]); 
  const [selectedRoleUserAccountIds, setSelectedRoleUserAccountIds] = useState([]);
  const [accountIds, setaccountIds] = useState([]);
    useState(fetchProjects());
    useState(fetchRoles());
  let [userCount, setUserCount] = useState(1);
  const onSubmit = values => {
        console.log("values in edit",values);
    return values;

  };

  const handleAddButtonClick = () => {
    let value = userCount;
    setUserCount(value+1);
    // console.log(userCount)
    // setSomeCount(count => count +1);
  };

  const renderUserFields = () => {
    const userFields = [];
    let users = {}
    for (let i = 0; i < userCount; i++) {
      // users[<UserPicker lable="user" name={`user${i}`} text="Picker User" />] =   <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />
      userFields.push(
        
        <UserPicker lable="user" name={`user${i}`} text="Picker User" /> 
         
        // <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />

      );
    }


    return userFields;
  };

  async function fetchProjects() {
    try {
      console.log("entered fetchProjects")
      const response = await api.asUser().requestJira(route`/rest/api/3/project/search`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchProjects")
      const responseJson = await response.json();
      //const issueArray = responseJson.issues.map(obj => obj.key);
      setProjects(responseJson.values);
      //console.log("Projects:", responseJson.values);
      console.log("exit fetchProjects")
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
    }
  
  async function fetchRoles() {
  // Inside fetchRoles function
//export const roleUsersJson = await roleUsersResponse.json();
//export const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
    try {
      // Fetch roles API call
            console.log("entered fetchroles")
      const response = await api.asUser().requestJira(route`/rest/api/3/role`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchrole")
      const responseJson = await response.json();
      setRoles(responseJson);
      console.log("exit fetchrole")
    } catch (error) {
      console.error("Error fetching roles:", error);
    }
  }

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <Select
          label="Select Project"
          name="project" // Add the name prop
          value={project}
          onChange={(newValue) => setProject(newValue)}
        >
          <Option label="Select a project" value="" />
        {projects.map((proj) => (
          <Option key={proj.id} label={proj.name} value={proj.key} />
        ))}
      </Select>
      <Select
        label="Select Role"
        name="roles"
        value={roles}
        onChange={(newRoles) => setRoles(newRoles)}
      >
	<Option label='All' value='all' />
        {roles.map((role) => (
          <Option key={role.id} label={role.name} value={role.id} />
        ))}
      </Select>
      <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
    </DashboardGadgetEdit>
  );
};


export default Edit;*/



//modifying code to display roles


/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, TextField, DatePicker, Select, Option,Button,render,Text,User,DashboardGadget,useProductContext,setSelectedUnit } from "@forge/ui";
import api, { route } from "@forge/api";

const Edit = () => {
  // let [someCount,setSomeCount] = useState(0)

   const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [project, setProject] = useState("");
  const [projects, setProjects] = useState([]);
  const [roles, setRoles] = useState([]); 
  const [selectedRoleUserAccountIds, setSelectedRoleUserAccountIds] = useState([]);
  const [accountIds, setaccountIds] = useState([]);
  const [dateDuration, setDateDuration] = useState("");
  const [dateUnit, setDateUnit] = useState(""); 
    useState(fetchProjects());
    useState(fetchRoles());
  let [userCount, setUserCount] = useState(1);
  const onSubmit = values => {
        console.log("values in edit",values);
    return values;

  };

  const handleAddButtonClick = () => {
    let value = userCount;
    setUserCount(value+1);
    // console.log(userCount)
    // setSomeCount(count => count +1);
  };

  const renderUserFields = () => {
    const userFields = [];
    let users = {}
    for (let i = 0; i < userCount; i++) {
      // users[<UserPicker lable="user" name={`user${i}`} text="Picker User" />] =   <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />
      userFields.push(
        
        <UserPicker lable="user" name={`user${i}`} text="Picker User" /> 
         
        // <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />

      );
    }


    return userFields;
  };

  async function fetchProjects() {
    try {
      console.log("entered fetchProjects")
      const response = await api.asUser().requestJira(route`/rest/api/3/project/search`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchProjects")
      const responseJson = await response.json();
      //const issueArray = responseJson.issues.map(obj => obj.key);
      setProjects(responseJson.values);
      //console.log("Projects:", responseJson.values);
      console.log("exit fetchProjects")
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
    }
  
  async function fetchRoles() {
  // Inside fetchRoles function
//export const roleUsersJson = await roleUsersResponse.json();
//export const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
    try {
      // Fetch roles API call
            console.log("entered fetchroles")
      const response = await api.asUser().requestJira(route`/rest/api/3/role`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchrole")
      const responseJson = await response.json();
      setRoles(responseJson);
      console.log("exit fetchrole")
    } catch (error) {
      console.error("Error fetching roles:", error);
    }
  }

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <Select
          label="Select Project"
          name="project" // Add the name prop
          value={project}
          onChange={(newValue) => setProject(newValue)}
        >
          <Option label="Select a project" value="" />
        {projects.map((proj) => (
          <Option key={proj.id} label={proj.name} value={proj.key} />
        ))}
      </Select>
      <Select
        label="Select Role"
        name="roles"
        value={roles}
        onChange={(newRoles) => setRoles(newRoles)}
      >
	<Option label='All' value='all' />
        {roles.map((role) => (
          <Option key={role.id} label={role.name} value={role.id} />
        ))}
      </Select>
      <TextField
        label="Search by Date Duration"
        name="dateDuration"
        value={dateDuration}
        onChange={(newValue) => setDateDuration(newValue)}
        placeholder="Enter duration"
      />
      <Select
        label="Select Date Unit" // Updated label
        name="dateUnit"
        value={dateUnit}
        onChange={(newValue) => setDateUnit(newValue)}
      >
        <Option label="Select a unit" value="" />
        <Option label="Days" value="days" />
        <Option label="Weeks" value="weeks" />
        <Option label="Months" value="months" />
      </Select>
    </DashboardGadgetEdit>
  );
};


export default Edit;*/

/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, TextField, DatePicker, Select, Option,Button,render,Text,User,DashboardGadget,useProductContext,setSelectedUnit } from "@forge/ui";
import api, { route } from "@forge/api";

const Edit = () => {
  // let [someCount,setSomeCount] = useState(0)

   const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [project, setProject] = useState("");
  const [projects, setProjects] = useState([]);
  const [roles, setRoles] = useState([]); 
  const [selectedRoleUserAccountIds, setSelectedRoleUserAccountIds] = useState([]);
  const [accountIds, setaccountIds] = useState([]);
  const [dateDuration, setDateDuration] = useState("");
  const [dateUnit, setDateUnit] = useState(""); 
  const [dateValue, setDateValue] = useState(""); 
  const [timeInterval, setTimeInterval] = useState("");
  const [timeValue, setTimeValue] = useState("");
  const [timeUnit, setTimeUnit] = useState(""); // Add this line
  const [workData, setWorkData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
    useState(fetchProjects());
    useState(fetchRoles());
  let [userCount, setUserCount] = useState(1);
  const onSubmit = values => {
        console.log("values in edit",values);
    return values;

  };

  const handleAddButtonClick = () => {
    let value = userCount;
    setUserCount(value+1);
    // console.log(userCount)
    // setSomeCount(count => count +1);
  };

  const renderUserFields = () => {
    const userFields = [];
    let users = {}
    for (let i = 0; i < userCount; i++) {
      // users[<UserPicker lable="user" name={`user${i}`} text="Picker User" />] =   <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />
      userFields.push(
        
        <UserPicker lable="user" name={`user${i}`} text="Picker User" /> 
         
        // <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />

      );
    }


    return userFields;
  };

  async function fetchProjects() {
    try {
      console.log("entered fetchProjects")
      const response = await api.asUser().requestJira(route`/rest/api/3/project/search`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchProjects")
      const responseJson = await response.json();
      //const issueArray = responseJson.issues.map(obj => obj.key);
      setProjects(responseJson.values);
      //console.log("Projects:", responseJson.values);
      console.log("exit fetchProjects")
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
    }
  
  async function fetchRoles() {
  // Inside fetchRoles function
//export const roleUsersJson = await roleUsersResponse.json();
//export const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
    try {
      // Fetch roles API call
            console.log("entered fetchroles")
      const response = await api.asUser().requestJira(route`/rest/api/3/role`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchrole")
      const responseJson = await response.json();
      setRoles(responseJson);
      console.log("exit fetchrole")
    } catch (error) {
      console.error("Error fetching roles:", error);
    }
  }

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <Select
          label="Select Project"
          name="project" // Add the name prop
          value={project}
          onChange={(newValue) => setProject(newValue)}
        >
          <Option label="Select a project" value="" />
        {projects.map((proj) => (
          <Option key={proj.id} label={proj.name} value={proj.key} />
        ))}
      </Select>
      <Select
        label="Select Role"
        name="roles"
        value={roles}
        onChange={(newRoles) => setRoles(newRoles)}
      >
	<Option label='All' value='all' />
        {roles.map((role) => (
          <Option key={role.id} label={role.name} value={role.id} />
        ))}
      </Select>
      <TextField
        label="Enter Duration"
        name="dateValue"
        value={dateValue}
        onChange={(newValue) => setDateValue(newValue)}
        placeholder="Enter duration"
      />
      <Text content="Within the last" />
      <Text content="_" />
      <Select
        label="Select Time Unit:"
        name="timeUnit"
        value={timeUnit}
        onChange={(newValue) => setTimeUnit(newValue)}
      >
        <Option label="Select a unit" value="" />
        <Option label="Days" value="days" />
        <Option label="Weeks" value="weeks" />
        <Option label="Months" value="months" />
      </Select>
    </DashboardGadgetEdit>
  );
};


export default Edit;*/



import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, TextField, DatePicker, Select, Option,Button,render,Text,User,DashboardGadget,useProductContext,setSelectedUnit,Macro, Table, Head, Cell, Row,RadioGroup, Radio } from "@forge/ui";
import api, { route } from "@forge/api";

const Edit = () => {
  // let [someCount,setSomeCount] = useState(0)

   const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [project, setProject] = useState("");
  const [projects, setProjects] = useState([]);
  const [roles, setRoles] = useState([]); 
  const [selectedRoleUserAccountIds, setSelectedRoleUserAccountIds] = useState([]);
  const [accountIds, setaccountIds] = useState([]);
  const [dateDuration, setDateDuration] = useState("");
  const [dateUnit, setDateUnit] = useState(""); 
  const [dateValue, setDateValue] = useState(""); 
  const [timeInterval, setTimeInterval] = useState("");
  const [timeValue, setTimeValue] = useState("");
  const [timeUnit, setTimeUnit] = useState(""); // Add this line
  const [workData, setWorkData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
    const [showCustomFields, setShowCustomFields] = useState(false);
      const [showCustomDatePicker, setShowCustomDatePicker] = useState(false);
      const isCustomSelected = timeUnit === 'Custom';
        const [showDatePicker, setShowDatePicker] = useState(false);
          const [customDate, setCustomDate] = useState('');
    useState(fetchProjects());
    useState(fetchRoles());
  let [userCount, setUserCount] = useState(1);
  const onSubmit = values => {
        console.log("values in edit",values);
    return values;

  };

  const handleAddButtonClick = () => {
    let value = userCount;
    setUserCount(value+1);
    // console.log(userCount)
    // setSomeCount(count => count +1);
  };

 const handleTimeUnitChange = (newValue) => {
    setTimeUnit(newValue);
  };

const handleStartDateChange = (newValue) => {
  setStartDate(newValue);
};

const handleCustomDateChange = (newValue) => {
  handleStartDateChange(newValue);
};

  const renderUserFields = () => {
    const userFields = [];
    let users = {}
    for (let i = 0; i < userCount; i++) {
     
      userFields.push(
        
        <UserPicker label="user" name={`user${i}`} text="Picker User" /> 
         
        // <TextField key={i} name={`name${i}`} label={`Say hello to user ${i + 1}:`} />

      );
    }


    return userFields;
  };

  async function fetchProjects() {
    try {
      console.log("entered fetchProjects")
      const response = await api.asUser().requestJira(route`/rest/api/3/project/search`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchProjects")
      const responseJson = await response.json();
      //const issueArray = responseJson.issues.map(obj => obj.key);
      setProjects(responseJson.values);
      //console.log("Projects:", responseJson.values);
      console.log("exit fetchProjects")
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
    }
  
  async function fetchRoles() {
  // Inside fetchRoles function
//export const roleUsersJson = await roleUsersResponse.json();
//export const accountIds = roleUsersJson.actors.map((actor) => actor.actorUser.accountId);
    try {
      // Fetch roles API call
            console.log("entered fetchroles")
      const response = await api.asUser().requestJira(route`/rest/api/3/role`, {
        headers: {
          'content-type': 'application/json'
        }
      });
      console.log("fetchrole")
      const responseJson = await response.json();
      setRoles(responseJson);
      console.log("exit fetchrole")
    } catch (error) {
      console.error("Error fetching roles:", error);
    }
  }
  
  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <Select
          label="Select Project"
          name="project" // Add the name prop
          value={project}
          onChange={(newValue) => setProject(newValue)}
        >
          <Option label="Select a project" value="" />
        {projects.map((proj) => (
          <Option key={proj.id} label={proj.name} value={proj.key} />
        ))}
      </Select>
      <Select
        label="Select Role"
        name="roles"
        value={roles}
        onChange={(newRoles) => setRoles(newRoles)}
      >
	<Option label='All' value='all' />
        {roles.map((role) => (
          <Option key={role.id} label={role.name} value={role.id} />
        ))}
      </Select>
    <RadioGroup name="timeUnit" label="Select Time Unit:" value={timeUnit} onChange={handleTimeUnitChange}>
        <Radio label="Last Week" value="Last Week" />
        <Radio label="Last Month" value="Last Month" />
        <Radio label="Last 3 Month" value="Last 3 Month" />
        <Radio label="Custom" value="Custom" />
      </RadioGroup>
    <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
      
    </DashboardGadgetEdit>
  );
};


export default Edit;


