// api.js
/*import api from "@forge/api";

export const fetchLogworkByUser = async (userName) => {
  try {
    const response = await api.asUser().requestJira(`/rest/api/3/search?jql=worklogAuthor=${userName}&fields=timetracking`);
    const data = await response.json();

    let totalSeconds = 0;
    if (data && data.issues) {
      data.issues.forEach((issue) => {
        if (issue.fields && issue.fields.timetracking) {
          totalSeconds += issue.fields.timetracking.timeSpentSeconds;
        }
      });
    }

    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  } catch (error) {
    console.error("Error fetching logwork:", error);
    return null;
  }
};
*/
// api.js
import api, { route } from "@forge/api";

export const fetchLogworkByUser = async (userName) => {
  try {
    const response = await api.asUser().requestJira(route`/rest/api/3/search?jql=worklogAuthor=${userName}&fields=timetracking`);
    const data = await response.json();

    let totalSeconds = 0;
    if (data && data.issues) {
      data.issues.forEach((issue) => {
        if (issue.fields && issue.fields.timetracking) {
          totalSeconds += issue.fields.timetracking.timeSpentSeconds;
        }
      });
    }

    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  } catch (error) {
    console.error("Error fetching logwork:", error);
    console.error("Error response:", await error.response.json()); // Log the error response
    console.error("Error status:", error.status); // Log the error status
    return null;
  }
};

