// app/src/view.jsx
/*import ForgeUI, { DashboardGadget, Text, useProductContext, useState, useEffect } from "@forge/ui";
import api, { route } from "@forge/api";
import { Bar } from "react-chartjs-2";

const fetchIssueData = async (username, startDate, endDate) => {
  try {
    console.log("Fetching logwork for user:", username, "within the time interval:", startDate, endDate);

    // Construct the JQL query to search for worklogs within the given time interval
    const jqlQuery = `worklogAuthor in (${username}) AND worklogDate >= "${startDate}" AND worklogDate <= "${endDate}"`;
    const response = await api.asUser().requestJira(route`/rest/api/3/search?jql=${jqlQuery}&fields=timetracking`);
    const data = await response.json();
    console.log("API response:", data);

    let totalSeconds = 0;
    if (data && data.issues) {
      data.issues.forEach((issue) => {
        if (issue.fields && issue.fields.timetracking) {
          totalSeconds += issue.fields.timetracking.timeSpentSeconds;
        }
      });
    }

    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const logworkData = `${hours}h ${minutes}m`;

    console.log("API Response:", logworkData);
    return logworkData;
  } catch (error) {
    console.error("Error fetching logwork:", error);
    console.error("Error response:", await error.response.json());
    console.error("Error status:", error.status);
    return null;
  }
};

const View = () => {
  const [logwork, setLogwork] = useState("");
  const { extensionContext: { gadgetConfiguration } } = useProductContext();

  useEffect(() => {
    console.log("useEffect triggered");
    console.log("gadgetConfiguration.User:", gadgetConfiguration.User);

    async function fetchLogwork() {
      if (!gadgetConfiguration.User || gadgetConfiguration.User.length === 0) {
        setLogwork(null);
        return;
      }

      // Get the selected user(s) from the UserPicker field
      const selectedUsernames = gadgetConfiguration.User.map((user) => user).join(",");
      console.log("Selected Usernames:", selectedUsernames);

      // Get the selected time interval from the gadget configuration
      const startDate = gadgetConfiguration.StartDate;
      const endDate = gadgetConfiguration.EndDate;

      if (!startDate || !endDate) {
        setLogwork(null);
        return;
      }

      const logworkData = await fetchIssueData(selectedUsernames, startDate, endDate);
      setLogwork(logworkData);
    }

    fetchLogwork();
  }, [gadgetConfiguration.User, gadgetConfiguration.StartDate, gadgetConfiguration.EndDate]);

  const chartData = {
    labels: ["Logged Work Hours"],
    datasets: [
      {
        label: "Work Hours",
        data: [logwork ? parseFloat(logwork) : 0],
        backgroundColor: ["rgba(75, 192, 192, 0.6)"],
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <DashboardGadget>
      <Text content="Logged Work Hours" />
      {gadgetConfiguration.User && gadgetConfiguration.User.length > 0 && (
        <Text content={`Selected User(s): ${gadgetConfiguration.User.join(", ")}`} />
      )}
      {gadgetConfiguration.StartDate && gadgetConfiguration.EndDate && (
        <Text content={`Time Interval: ${gadgetConfiguration.StartDate} - ${gadgetConfiguration.EndDate}`} />
      )}
      {logwork !== null ? (
        <Bar data={chartData} options={chartOptions} />
      ) : (
        <Text content="Fetching logwork..." />
      )}
    </DashboardGadget>
  );
};

export default View;
*/
// app/src/view.jsx
import ForgeUI, { DashboardGadget, useState, useEffect, Text } from "@forge/ui";
import api, { route } from "@forge/api";

const View = () => {
  const [logwork, setLogwork] = useState("Fetching logwork...");

  const fetchNumberOfIssues = async (username, startDate, endDate) => {
    try {
      console.log("Fetching logwork for user:", username, "within the time interval:", startDate, endDate);

      // Construct the JQL query to search for worklogs within the given time interval
      //const jqlQuery = `worklogAuthor in (${username}) AND worklogDate >= "${startDate}" AND worklogDate <= "${endDate}"`;
      const jqlQuery = `worklogAuthor in (${username}) AND updated >= "${startDate}" AND updated <= "${endDate}"`;
      console.log("jqlQuery", jqlQuery);
      const response = await api.asUser().requestJira(route`/rest/api/3/search?jql=${jqlQuery}&fields=timetracking`);
      console.log("response", response);
      const data = await response.json();
      console.log("API response:", data);

      let totalSeconds = 0;
      if (data && data.issues) {
        data.issues.forEach((issue) => {
          if (issue.fields && issue.fields.timetracking) {
            totalSeconds += issue.fields.timetracking.timeSpentSeconds;
          }
        });
      }

      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const logworkData = `${hours}h ${minutes}m`;

      console.log("API Response:", logworkData);
      return logworkData;
    } catch (error) {
      console.error("Error fetching logwork:", error);
      console.error("Error response:", await error.response.json());
      console.error("Error status:", error.status);
      return null;
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      // Get the selected users and date range from gadget configuration
      const { User, StartDate, EndDate } = api.store.getState().extensionContext.gadgetConfiguration;
      if (!User || User.length === 0 || !StartDate || !EndDate) {
        setLogwork("Please select users and provide a valid date range.");
        return;
      }

      // Get the selected user(s) from the UserPicker field
      const selectedUsernames = User.map((user) => user).join(",");

      // Fetch the logwork data
      const logworkData = await fetchNumberOfIssues(selectedUsernames, StartDate, EndDate);
      setLogwork(logworkData);
    };

    fetchData();
  }, []);

  return (
    <DashboardGadget>
      {logwork ? (
        <Text content={`Logwork: ${logwork}`} />
      ) : (
        <Text content="Fetching logwork..." />
      )}
    </DashboardGadget>
  );
};

export default View;

// app/src/view.jsx
/*import ForgeUI, { DashboardGadget, useState, useEffect, Text } from "@forge/ui";
import api, { route } from "@forge/api";

const View = () => {
  const [logworkData, setLogworkData] = useState([]);

  const fetchLogworkData = async (selectedUsers, startDate, endDate) => {
    try {
      console.log("Fetching logwork data for users:", selectedUsers, "within the time interval:", startDate, endDate);

      // Fetch the logwork data for each user separately
      const logworkDataPromises = selectedUsers.map(async (user) => {
        const username = user.accountId; // Get the user's accountId from the UserPicker
        // Construct the JQL query to search for worklogs within the given time interval for each user
        const jqlQuery = `worklogAuthor in (${username}) AND updated >= "${startDate}" AND updated <= "${endDate}"`;
        const response = await api.asUser().requestJira(route`/rest/api/3/search?jql=${jqlQuery}&fields=timetracking`);
        const data = await response.json();

        let totalSeconds = 0;
        if (data && data.issues) {
          data.issues.forEach((issue) => {
            if (issue.fields && issue.fields.timetracking) {
              totalSeconds += issue.fields.timetracking.timeSpentSeconds;
            }
          });
        }

        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const logwork = `${hours}h ${minutes}m`;

        return { username, logwork };
      });

      return Promise.all(logworkDataPromises);
    } catch (error) {
      console.error("Error fetching logwork:", error);
      console.error("Error response:", await error.response.json());
      console.error("Error status:", error.status);
      return [];
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      // Get the selected users and date range from gadget configuration
      const { User, StartDate, EndDate } = api.store.getState().extensionContext.gadgetConfiguration;

      if (!User || User.length === 0 || !StartDate || !EndDate) {
        setLogworkData([]);
        return;
      }

      // Fetch the logwork data
      const logworkData = await fetchLogworkData(User, StartDate, EndDate);
      setLogworkData(logworkData);
    };

    fetchData();
  }, []);

  return (
    <DashboardGadget>
      {logworkData && logworkData.length > 0 ? (
        logworkData.map((data, index) => (
          <Text key={index} content={`User: ${data.username}, Logwork: ${data.logwork}`} />
        ))
      ) : (
        <Text content="Fetching logwork..." />
      )}
    </DashboardGadget>
  );
};

export default View;*/


