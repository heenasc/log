// app/src/edit.jsx
// app/src/edit.jsx
/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, api, TextField, DatePicker } from "@forge/ui";

const Edit = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const onSubmit = async (values) => {
    // Handle file upload and store the file in the app's storage using the Forge storage API
    if (values.CsvFile) {
      const fileContent = await values.CsvFile.read(); // Read the file content
      const fileName = values.CsvFile.name; // Get the file name
      // Store the file in the app's storage
      await api.asApp().requestJira(route`/rest/forge/api/storage/${fileName}`, {
        method: "PUT",
        body: fileContent,
      });
    }

    // Save the selected start date and end date to gadget configuration
    api.store.onGadgetConfigurationChange((configuration) => {
      configuration.StartDate = startDate;
      configuration.EndDate = endDate;
      return configuration;
    });

    return "Data saved successfully"; // Return a valid child element or a string
  };

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <UserPicker label="User" name="User" isMulti="true" />
      <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
      <TextField name="CsvFile" label="Upload CSV File" type="file" accept=".csv" />
    </DashboardGadgetEdit>
  );
};

export default Edit;
*/
// app/src/edit.jsx
// app/src/edit.js
import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, api, TextField, DatePicker } from "@forge/ui";
import { route } from "@forge/api"; 
const Edit = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const onSubmit = async (values) => {
    try {
      // Handle file upload and store the file in the app's storage using the Forge storage API
      if (values.CsvFile) {
        const fileContent = await values.CsvFile.read(); // Read the file content
        const fileName = values.CsvFile.name; // Get the file name
        // Store the file in the app's storage
        await api.asApp().requestJira(route`/rest/forge/api/storage/${fileName}`, {
          method: "PUT",
          body: fileContent,
        });
      }

      // Save the selected start date and end date to gadget configuration
      api.store.onGadgetConfigurationChange((configuration) => {
        configuration.StartDate = startDate;
        configuration.EndDate = endDate;
        return configuration;
      });

      return "Data saved successfully"; // Return a valid child element or a string
    } catch (error) {
      console.error("Error on form submission:", error);
      return "Error occurred while saving data"; // Return a valid child element or a string
    }
  };

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <UserPicker label="User" name="User" isMulti="true" />
      <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
      <TextField name="CsvFile" label="Upload CSV File" type="file" accept=".csv" />
    </DashboardGadgetEdit>
  );
};

export default Edit;

// app/src/edit.jsx
// app/src/edit.js

// app/src/edit.js
// app/src/edit.js
/*import ForgeUI, { DashboardGadgetEdit, UserPicker, useState, useEffect, DatePicker, FilePicker, api } from "@forge/ui";

const Edit = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedUsers, setSelectedUsers] = useState([]);

  useEffect(() => {
    // Fetch the current user's information and set it as the default selected user
    api.asUser().me().then((user) => {
      setSelectedUsers([{ accountId: user.accountId, displayName: user.displayName }]);
    });
  }, []);

  const onSubmit = async (values) => {
    try {
      // Save the selected start date, end date, and users to gadget configuration
      api.store.onGadgetConfigurationChange((configuration) => {
        configuration.StartDate = startDate;
        configuration.EndDate = endDate;
        configuration.User = selectedUsers;
        return configuration;
      });

      return "Data saved successfully"; // Return a valid child element or a string
    } catch (error) {
      console.error("Error on form submission:", error);
      return "Error occurred while saving data"; // Return a valid child element or a string
    }
  };

  return (
    <DashboardGadgetEdit onSubmit={onSubmit}>
      <UserPicker
        label="User"
        name="User"
        isMulti="true"
        onChange={(newValue) => setSelectedUsers(newValue)}
        value={selectedUsers}
      />
      <DatePicker name="StartDate" label="Start Date" value={startDate} onChange={(newValue) => setStartDate(newValue)} />
      <DatePicker name="EndDate" label="End Date" value={endDate} onChange={(newValue) => setEndDate(newValue)} />
    </DashboardGadgetEdit>
  );
};

export default Edit;*/

